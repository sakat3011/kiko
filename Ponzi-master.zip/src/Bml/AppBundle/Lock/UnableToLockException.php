<?php


namespace Bml\AppBundle\Lock;

/**
 * @author Damian Wróblewski <d.wroblewski@madden.pl>
 * @package Bml\AppBundle\Lock
 */
class UnableToLockException extends \RuntimeException
{

}
